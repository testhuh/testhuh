(function(){
  'use strict';
  var guide=document.getElementById('workflowGuide');if(!guide)return;
  var buttons=Array.prototype.slice.call(guide.querySelectorAll('[data-guide-step]'));
  var panels=Array.prototype.slice.call(guide.querySelectorAll('[data-guide-panel]'));
  var pause=document.getElementById('guidePause'), replay=document.getElementById('guideReplay');
  var info=document.getElementById('guidePlayback'),current=0,timer=null,visible=false;
  // Start still: reading a stage must not move the page or advance the user's work.
  var media=window.matchMedia('(prefers-reduced-motion: reduce)'),playing=false;
  var checklist=[
    {who:'자료 수집 · 검수자 / 시스템',items:[['입력','원문·기초 자료와 출처를 준비합니다.'],['확인','파일을 열어 내용과 누락 페이지를 확인합니다.'],['완료 조건','초안 작성에 사용할 자료가 준비됐습니다.']],note:'준비 대상 건수는 미착수 자료 기준입니다. 자동 수집의 성공 건수가 아닙니다.'},
    {who:'초안 생성 · 시스템 / 검수자',items:[['입력','원천 자료와 문서 양식을 사용합니다.'],['확인','초안 내용·출처·[부족] 항목을 확인합니다.'],['완료 조건','검토 가능한 초안과 생성 결과가 있습니다.']],note:'Gauss 설정 유무와 실제 초안 생성 성공은 구분해서 확인합니다.'},
    {who:'대외 필터 · 시스템 / 전략부서 검수자',items:[['자동 처리','규칙에 따른 제외 결과를 확인합니다.'],['담당자 판단','보류 문구를 삭제하지 않고 포함·제외를 판정합니다.'],['완료 조건','담당자가 필요한 보류 판정을 마쳤습니다.']],note:'대외용 문서에 적용되는 단계입니다. 내부 문서에 같은 필터를 강제하지 않습니다.'},
    {who:'검수·승인 · 검수자 → 별도 승인자',items:[['검수자','초안을 수정하고 수정본을 올려 승인을 요청합니다.'],['승인자','내용을 확인해 승인 또는 사유와 함께 수정 요청합니다.'],['완료 조건','승인된 수정본의 버전이 확정됐습니다.']],note:'검수자와 승인자는 다릅니다. 승인 완료만으로 게시 완료가 되지 않습니다.'},
    {who:'등록·배포 · 시스템 / 지정된 첨부 담당자',items:[['① 글 생성','승인본 버전과 게시 위치를 확인합니다.'],['② 첨부 요청·③ 첨부','담당자가 승인본 파일을 게시글에 첨부합니다.'],['④ 첨부 확인','게시글과 승인본 파일이 일치하는지 확인합니다.']],note:'승인 완료 대상을 조회합니다. 실제 글 생성·첨부·확인 상태는 문서별 등록 진행에서 확인하세요.'}
  ];
  function select(index){
    current=Math.max(0,Math.min(index,buttons.length-1));
    buttons.forEach(function(b,i){b.setAttribute('aria-pressed',String(i===current));b.closest('.workflow-card').classList.toggle('guide-selected',i===current);});
    panels.forEach(function(panel,i){panel.hidden=i!==current;});
    var data=checklist[current],list=document.getElementById('stageChecklist');
    if(list){list.replaceChildren();data.items.forEach(function(item){var row=document.createElement('li'),title=document.createElement('strong'),desc=document.createElement('small');title.textContent=item[0];desc.textContent=item[1];row.append(title,desc);list.appendChild(row);});document.getElementById('stageWho').textContent=data.who;document.getElementById('stageBoundary').textContent=data.note;}
  }
  function stopTimer(){if(timer!==null){clearInterval(timer);timer=null;}}
  function update(){
    stopTimer();
    var active=playing && !media.matches && visible && !document.hidden && document.body.dataset.page==='overview';
    pause.textContent=playing?'❚❚':'▶';pause.title=playing?'단계 안내 일시정지':'단계 안내 재생';pause.setAttribute('aria-label',pause.title);
    guide.classList.toggle('guide-playing',active);
    info.textContent=media.matches?'단계를 직접 선택하세요. 움직임 줄이기 설정이 적용됐습니다.':playing?(active?'단계 설명을 순서대로 보여줍니다. 실제 문서 상태는 변경되지 않습니다.':'단계 안내가 잠시 멈춰 있습니다.'):'단계 선택은 설명만 바꿉니다. 아래 업무 버튼으로 작업을 시작하세요.';
    if(active){timer=setInterval(function(){if(current>=buttons.length-1){playing=false;update();return;}select(current+1);},5000);}
  }
  buttons.forEach(function(b){b.addEventListener('click',function(){playing=false;select(Number(b.dataset.guideStep));update();});});
  pause.addEventListener('click',function(){if(media.matches){info.textContent='움직임 줄이기 설정으로 단계는 직접 선택할 수 있습니다.';return;}if(!playing&&current===buttons.length-1)select(0);playing=!playing;update();});
  replay.addEventListener('click',function(){select(0);playing=!media.matches;update();});
  document.addEventListener('visibilitychange',update);window.addEventListener('hashchange',update);
  if(media.addEventListener)media.addEventListener('change',function(){if(media.matches)playing=false;update();});
  else if(media.addListener)media.addListener(function(){if(media.matches)playing=false;update();});
  if('IntersectionObserver' in window){var obs=new IntersectionObserver(function(entries){visible=entries[0].isIntersecting;update();},{threshold:0.15});obs.observe(guide);}else{visible=true;}
  select(0);update();
})();
