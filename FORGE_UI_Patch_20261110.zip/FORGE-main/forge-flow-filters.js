/* Shared display filters. Approval is not evidence of Mosaic publication. */
window.ForgeFlowFilters = {
  matches: function(s, f){
    switch(f){
      case 'review': return s.active_status === 'P3';
      case 'review_stage': return ['P3','P4','P5'].indexOf(s.active_status) >= 0;
      case 'approval': return s.active_status === 'P4';
      case 'approved': return !!s.approved;
      case 'revision': return s.active_status === 'P5';
      case 'draft': return s.active_status === 'P1';
      case 'filter': return s.active_status === 'P2';
      case 'collect': return !s.active_run_id && !s.approved && s.last_status !== 'P6';
      case 'release': return !!s.approved || s.last_status === 'P6';
      default: return true;
    }
  }
};
