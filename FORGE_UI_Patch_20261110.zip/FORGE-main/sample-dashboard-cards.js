(function(){
  'use strict';
  var cards=Array.from(document.querySelectorAll('[data-slot-summary]'));
  if(!cards.length)return;
  var note=document.getElementById('dashboardDataState'),retry=document.getElementById('retryDashboard');
  var counts=Array.from(document.querySelectorAll('[data-stage-count]'));
  var filters={collect:'collect',draft:'draft',filter:'filter',review:'review_stage',release:'release'};
  var loading=false;
  cards.forEach(function(card){card.dataset.defaultNote=card.querySelector('p').textContent;card.addEventListener('click',function(){location.hash='library?filter='+encodeURIComponent(card.dataset.slotSummary);});});
  function get(path){var controller=new AbortController(),timeout=setTimeout(function(){controller.abort();},10000);return fetch(path,{credentials:'same-origin',signal:controller.signal}).then(function(r){if(!r.ok)throw new Error(r.status===401?'로그인이 필요합니다':r.status===403?'조회 권한을 확인해 주세요':'업무 API 조회 실패 (HTTP '+r.status+')');return r.json().catch(function(){throw new Error('업무 API의 JSON 응답을 확인하지 못했습니다');});}).finally(function(){clearTimeout(timeout);});}
  function refresh(){
    if(loading)return;loading=true;if(retry)retry.disabled=true;
    if(note)note.textContent='업무 현황을 조회하고 있습니다…';
    cards.forEach(function(c){c.disabled=true;c.querySelector('.metric-value').textContent='—';});counts.forEach(function(c){c.textContent='조회 중…';});
    Promise.allSettled([get('api/flow/board'),get('api/flow/me')]).then(function(results){
      if(results[0].status!=='fulfilled')throw results[0].reason;
      var data=results[0].value;if(!data||!Array.isArray(data.slots)||!data.slots.every(function(s){return s&&typeof s.product==='string'&&typeof s.doc_type==='string';}))throw new Error('문서 목록 응답 형식이 다릅니다');
      var me=results[1].status==='fulfilled'&&results[1].value;
      cards.forEach(function(card){var key=card.dataset.slotSummary,available=key!=='approved'||!!(me&&me.user);card.querySelector('.metric-value').textContent=available?String(data.slots.filter(function(s){return ForgeFlowFilters.matches(s,key);}).length):'—';card.disabled=!available;card.querySelector('p').textContent=card.dataset.defaultNote;if(key==='approved')card.querySelector('p').textContent=available?'승인본이 있는 목록 보기 →':'로그인 후 승인본 보유 여부 조회';});
      counts.forEach(function(c){var key=c.dataset.stageCount,n=data.slots.filter(function(s){return ForgeFlowFilters.matches(s,filters[key]);}).length;c.textContent=(key==='collect'?'준비 대상 ':key==='release'?'승인 완료 대상 ':'진행 ')+n+'건';});
      if(note)note.textContent=(me&&me.demo_mode?'샌드박스 데모 DB 조회':'업무 API 조회')+' · '+new Date().toLocaleTimeString('ko-KR',{timeZone:'Asia/Seoul'})+' KST · 승인본 보유 ≠ Mosaic 게시 완료';
      if(me&&me.demo_mode&&note)note.textContent+=' · 실제 운영 자료와 구분됩니다';
    }).catch(function(error){cards.forEach(function(c){c.querySelector('.metric-value').textContent='—';c.querySelector('p').textContent='데이터 연결 확인 필요';c.disabled=true;});counts.forEach(function(c){c.textContent='조회 미확인';});if(note)note.textContent=(error.name==='AbortError'?'업무 API 응답 시간 초과':error.message)+' · 0건으로 처리하지 않았습니다. 연결 확인 후 다시 조회해 주세요.';}).finally(function(){loading=false;if(retry)retry.disabled=false;});
  }
  if(retry)retry.addEventListener('click',refresh);
  window.addEventListener('hashchange',function(){if(!location.hash||location.hash==='#overview')refresh();});
  window.addEventListener('message',function(e){var frame=document.getElementById('forgeWorkspaceFrame');if(e.origin===location.origin&&frame&&e.source===frame.contentWindow&&e.data&&e.data.type==='forge:flow-updated')refresh();});
  refresh();
})();
